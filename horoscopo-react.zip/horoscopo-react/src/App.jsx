import { useState } from 'react'
import reactLogo from './assets/react.svg'
import './App.css'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Horoscopo from './components/Horoscopo';

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <Horoscopo/>
    </div>
  )
}

export default App
